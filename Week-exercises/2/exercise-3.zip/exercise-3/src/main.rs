pub mod new_module;
use new_module::new_file::calling_from_far;
fn main() {
    calling_from_far();
}
