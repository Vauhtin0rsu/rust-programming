pub mod game;
use game::Country::Country;

fn main() {
    use std::io;

    println!("| 1) Finland | 2) Sweden | 3) Norway | 4) Denmark |");
    println!("Choose your country: ");

    let mut input = String::new();
    io::stdin()
        .read_line(&mut input)
        .expect("Virhe syötteen lukemisessa");
    let input = input.trim();

    let i: i32 = input.trim().parse().unwrap();

    if i == 1 {
        let finland = Country::new(String::from("Finland"), 5600000, 900000, vec![], false);
        println!("Country: {}", finland.name);
        println!("Population: {}", finland.population);
        println!("Army size: {}", finland.army_size);

    } else if i == 2 {
        let sweden = Country::new(String::from("Sweden"), 10000000, 200000, vec![], false);
        println!("Country: {}", sweden.name);
        println!("Population: {}", sweden.population);
        println!("Army size: {}", sweden.army_size);

    } else if i == 3 {
        let norway = Country::new(String::from("Norwat"), 5500000, 100000, vec![], false);
        println!("Country: {}", norway.name);
        println!("Population: {}", norway.population);
        println!("Army size: {}", norway.army_size);

    } else if i == 4 {
        let denmark = Country::new(String::from("Denmark"), 6000000, 50000, vec![], false);
        println!("Country: {}", denmark.name);
        println!("Population: {}", denmark.population);
        println!("Army size: {}", denmark.army_size);

    }
}
