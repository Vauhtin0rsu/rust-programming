pub mod game;
use game::Country::Country;
use game::Player::Player;

fn main() {
    use std::io;

    println!("| 1) Finland | 2) Sweden | 3) Norway | 4) Denmark |");
    println!("Choose your country: ");

    let mut input = String::new();
    io::stdin()
        .read_line(&mut input)
        .expect("Virhe syötteen lukemisessa");
    let input = input.trim();

    let i: i32 = input.trim().parse().unwrap();

    let player: Player;

    if i == 1 {
        let finland = Country::new(String::from("Finland"), 5600000, 900000, vec![], false);
        player = Player::new(finland);        

    } else if i == 2 {
        let sweden = Country::new(String::from("Sweden"), 10000000, 200000, vec![], false);
        player = Player::new(sweden);

    } else if i == 3 {
        let norway = Country::new(String::from("Norwat"), 5500000, 100000, vec![], false);
        player = Player::new(norway);

    } else if i == 4 {
        let denmark = Country::new(String::from("Denmark"), 6000000, 50000, vec![], false);
        player = Player::new(denmark);
    } else {
        panic!("Invalid country selection");
    }

    println!("| Inspection on your own nation? | y = yes | n = no |");
    let mut input = String::new();    
    io::stdin()
        .read_line(&mut input)
        .expect("Virhe syötteen lukemisessa");
    let input = input.trim();

    if input == "y" {
        println!("An inspection has been completed..");
        player.inspect();

    } else if input == "n" {
        println!("The leader is confident. No inspection needed.");
    }

}
